# Algorithms - Scripts

Assignement from Charlie Edmunds to practice programming skills. This projects aims at level Gold.

## Installation

Move Scripts folder to /Assets folder of fresh Unity Project.

## Usage

Launch each algorithm from MyMenu submenu and read output in logs.

## Bibliography
Bubble sort explaination: https://www.geeksforgeeks.org/bubble-sort/
Quick sort pseudocode: https://www.geeksforgeeks.org/quick-sort/
Fibonacci number explaination: https://en.wikipedia.org/wiki/Fibonacci_number