﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fibonacci : Algorithm
{
    private int m_Index;
    private int m_Sum;

    public override void PrepareData(object data)
    {
        m_Index = Convert.ToInt32(data);
        m_Sum = 0;
    }

    public override void RunAlgorithm()
    {
        m_Sum = DoFibonacciFlip(m_Index);
    }
    public override void PrintResults()
    {
        Debug.Log(m_Sum);
    }

    private int DoFibonacciFlip(int index) // if index is 0 return 0, 1 if 1, else return fibonacci value for two previous indexes
    {
        if (index == 0)
        {
            return 0;
        }
        else if (index == 1)
        {
            return 1;
        }
        else
        {
            return DoFibonacciFlip(index - 1) + DoFibonacciFlip(index - 2);
        }
    }
}

