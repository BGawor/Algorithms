﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class BubbleSort : Algorithm // reference: https://www.geeksforgeeks.org/bubble-sort/
{
    public List<int> list;
    public int listLength;

    public override void PrepareData(object data)
    {
        list = data as List<int>;
        listLength = list.Count();
    }

    public override void RunAlgorithm()
    {
        Sort();
    }

    public override void PrintResults()
    {
        string result = ListToText(list);
        Debug.Log("Result = " + result);
    }

    private string ListToText(IEnumerable list)
    {
        string result = "";
        foreach (var listMember in list)
        {
            result += listMember.ToString() + " ";
        }
        return result;
    }

    private void Sort()
    {
        bool finished = true;
        for (int i = 0; i < listLength - 1; i++) //iterate over entire list
        {
            int listI = list[i];
            int listNext = list[i + 1];
            if (listI > listNext) // if current element is bigger than next, swap them
            {
                list[i] = listNext;
                list[i + 1] = listI;
                finished = false;
            }
        }
        if(!finished)
        {
            Sort(); // if any elements were swapped, run algorithm again
        }
    }
}
