﻿using System;
using System.Diagnostics;
using System.Linq;

public abstract class Algorithm
{
    private Stopwatch m_stopWatch = new Stopwatch();
    private bool m_BatchRun = false;

    private void StartTimer()
    {
        //m_stopWatch.Reset();
        m_stopWatch.Start();
    }

    private void StopTimer()
    {
        m_stopWatch.Stop();
    }

    public abstract void PrepareData(object data);

    public abstract void RunAlgorithm();

    public abstract void PrintResults();

    public TimeSpan Run(object data)
    {
        PrepareData(data);
        StartTimer();
        RunAlgorithm();
        StopTimer();
        if (!m_BatchRun)
        {
            PrintResults();
        }
        return m_stopWatch.Elapsed;
    }

    public string RunBatch(object Data, int numTimes)
    {
        m_BatchRun = true;
        TimeSpan[] runLength = new TimeSpan[numTimes];
        for (int i = 0; i < numTimes; i++)
        {
            runLength[i] = Run(Data);
        }
        double doubleAverageTicks = runLength.Average(timeSpan => timeSpan.Ticks);
        long longAverageTicks = Convert.ToInt64(doubleAverageTicks);

        TimeSpan averageLength = new TimeSpan(longAverageTicks);
        m_BatchRun = false;
        return "Average completion time is: " + averageLength.ToString();
    }
}
