﻿using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public static class RunDebug
{
    [MenuItem("MyMenu/RunFibonacci")]
    public static void RunFibonacci()
    {
        Algorithm algorithmClass = new Fibonacci();
        //List<int> emptyString = new List<int> { 1, 6, 7, 19, 20, 13, 4 };
        //List<string> emptyString = new List<string> {"a lion",
        //                                             "lion" };
        object data = 9;
        Debug.Log("Fibonacci");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }
    [MenuItem("MyMenu/RunBubbleSort")]
    public static void RunBubbleSort()
    {
        Algorithm algorithmClass = new BubbleSort();
        List<int> data = new List<int> { 1, 6, 7, 19, 20, 13, 4 };
        //List<string> emptyString = new List<string> {"a lion",
        //                                             "lion" };
        Debug.Log("SingleRun - BubbleSort");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }

    [MenuItem("MyMenu/RunQuickSort")]
    public static void RunQuickSort()
    {
        Algorithm algorithmClass = new QuickSort();
        List<int> data = new List<int> { 1, 6, 7, 19, 20, 13, 4 };
        //List<string> emptyString = new List<string> {"a lion",
        //                                             "lion" };
        Debug.Log("SingleRun - QuickSort");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }

    [MenuItem("MyMenu/RunGenericQuickSort")]
    public static void GenericQuickSort()
    {
        Algorithm algorithmClass = new GenericQuickSort<int>();
        IEnumerable<int> data = new List<int> { 1, 6, 7, 19, 20, 13, 4 };
        //List<string> emptyString = new List<string> {"a lion",
        //                                             "lion" };
        Debug.Log("SingleRun - GenericQuickSort");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }

    [MenuItem("MyMenu/RunGenericBubbleSort")]
    public static void RunGenericBubbleSort()
    {
        Algorithm algorithmClass = new GenericBubbleSort<int>();
        IEnumerable<int> data = new List<int> { 1, 6, 7, 19, 20, 13, 4 };
        //List<string> emptyString = new List<string> {"a lion",
        //                                             "lion" };
        Debug.Log("SingleRun - GenericBubbleSort");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }

    [MenuItem("MyMenu/RunDoesContainSubstring")]
    public static void RunDoesContainSubstring()
    {
        Algorithm algorithmClass = new DoesContainSubstring();
        List<string> data = new List<string> {"The dog has fought a lion! Isn't he amazing?!",
                                              "lion     isnt hea!m??.azing"};
        Debug.Log("SingleRun - DoesContainSubstring");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }

    [MenuItem("MyMenu/RunCustomSort")]
    public static void RunCustomSort()
    {
        Algorithm algorithmClass = new CustomSort();
        Dictionary<string, int> data = new Dictionary<string, int>();
        data.Add("Ziomek", 15);
        data.Add("Franek", 34);
        data.Add("Mateusz", 45);
        data.Add("Ronaldo", 53);
        data.Add("Edwardo", 99);
        data.Add("Venkatanarasimharajuvaripeta", 3);
        Debug.Log("SingleRun - CustomSort");
        RunAlgorithmWithPrintedResults(algorithmClass, data);
    }

    public static void RunAlgorithmWithPrintedResults(Algorithm algorithm, object data)
    {
        Debug.Log("SingleRun - results");
        algorithm.Run(data);
        Debug.Log("BatchRun");
        Debug.Log(algorithm.RunBatch(data, 100));
    }
}
