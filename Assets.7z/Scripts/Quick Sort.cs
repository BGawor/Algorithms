﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class QuickSort : Algorithm // reference: https://www.geeksforgeeks.org/quick-sort/ // comments are copied from pseudocode
{
    public List<int> list;
    public int startIndex;
    public int endIndex;

    public override void PrepareData(object data)
    {
        list = data as List<int>;
        startIndex = 0;
        endIndex = list.Count() - 1;
    }

    public override void RunAlgorithm()
    {
        quickSort(startIndex, endIndex);
    }

    public override void PrintResults()
    {
        string result = ListToText(list);
        Debug.Log("Result = " + result);
    }

    private string ListToText(IEnumerable list)
    {
        string result = "";
        foreach (var listMember in list)
        {
            result += listMember.ToString() + " ";
        }
        return result;
    }

    private void quickSort(int startIndex, int endIndex)
    {
        if (startIndex < endIndex)
        {
            /* pi is partitioning index, arr[pi] is now
               at right place */
            int pi = partition(startIndex, endIndex);

            quickSort(startIndex, pi - 1);  // Before pi
            quickSort(pi + 1, endIndex); // After pi
        }
    }

    private int partition(int startIndex, int endIndex)
    {
        // pivot (Element to be placed at right position)
        int pivot = list[endIndex];
        int i = (startIndex - 1);  // Index of smaller element

        for (int j = startIndex; j <= endIndex - 1; j++)
        {
            // If current element is smaller than the pivot
            int elementAtJ = list[j];
            if (elementAtJ < pivot)
            {
                i++;    // increment index of smaller element
                list[j] = list[i];
                list[i] = elementAtJ;
            }
        }
        // swap arr[i + 1] and arr[high])
        int tempInt = list[i + 1];
        list[i + 1] = list[endIndex];
        list[endIndex] = tempInt;
        return i + 1;
    }
}
