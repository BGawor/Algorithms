﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class DoesContainSubstring : Algorithm
{
    private string m_Text;
    private string m_SubString;
    private bool m_Result;

    public override void PrepareData(object data) // remove any non-alphanumeric symbols to make search algorith easy to implement
    {
        List<string> list = data as List<string>;
        m_Text = RemoveNonAlphaNumeric(list[0]);
        m_SubString = RemoveNonAlphaNumeric(list[1]);
        m_Text = m_Text.ToLower();
        m_SubString = m_SubString.ToLower();
    }

    public override void RunAlgorithm()
    {
        m_Result = Search();
    }

    public override void PrintResults()
    {
        Debug.Log(m_Result);
    }

    private bool Search()
    {
        int textLength = m_Text.Length;
        int subStringLength = m_SubString.Length;
        if (m_Text.Length < m_SubString.Length)
        {
            return false;
        }
        for (int i = 0; i < textLength; i++) // iterate over entire text
        {
            if (i + subStringLength > textLength) // if substring is longer than rest of text, dont bother searching
            {
                return false;
            }
            for (int j = 0; j < subStringLength; j++) // iterate over entire substring for every letter in text
            {
                char textLetter = m_Text[i+j]; // each iteration compares next letter from substring against next letter from text
                char subStringLetter = m_SubString[j];
                if (textLetter == subStringLetter)
                {
                    if (j == subStringLength - 1) // if entire substring was checked and matched, return true
                    {
                        return true;
                    }
                }
                else
                {
                    break; // if any letter didnt match, its pointless to check rest of substring
                }
            }
        }
        return false;
    }

    private string RemoveNonAlphaNumeric(string tempString)
    {
        char[] arr = tempString.Where(c => char.IsLetterOrDigit(c)).ToArray();

        return new string(arr);
    }
}
