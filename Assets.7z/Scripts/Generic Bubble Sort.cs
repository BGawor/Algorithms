﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GenericBubbleSort<T> : Algorithm where T : IComparable // reference: https://www.geeksforgeeks.org/bubble-sort/
{
    public IEnumerable<T> list ;
    public int listLength;

    public override void PrepareData(object data)
    {
        list = data as IEnumerable<T>; // list replaced by generic
        listLength = list.Count();
    }

    public override void RunAlgorithm()
    {
        Sort();
    }

    public override void PrintResults()
    {
        string result = ListToText(list);
        Debug.Log("Result = " + result);
    }

    private string ListToText(IEnumerable list)
    {
        string result = "";
        foreach (T listMember in list)
        {
            result += listMember.ToString() + " ";
        }
        return result;
    }

    private void Sort()
    {
        bool finished = true;
        for (int i = 0; i < listLength - 1; i++)
        {
            T listI = ReturnElementAtIndex(i);
            T listNext = ReturnElementAtIndex(i + 1);
            if (listI.CompareTo(listNext) > 0)
            {
                list = Replace(list, i, listNext);
                list = Replace(list, i + 1, listI);
                finished = false;
            }
        }
        if (!finished)
        {
            Sort();
        }
    }

    private T ReturnElementAtIndex(int index)
    {
        foreach (T item in list) // iterating over entire list, because IEnumerable has no option access certain index directly
        {
            if (index-- == 0)
            {
                return item;
            }
        }
        return default(T); // we're not handling errors
    }

    private IEnumerable<T> Replace(IEnumerable<T> enumerable, int index, T value)
    {
        int current = 0;
        foreach (var item in enumerable)
        {
            yield return current == index ? value : item;
            current++;
        }
    }
}
