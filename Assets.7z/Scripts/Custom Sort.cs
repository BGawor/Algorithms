﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CustomSort : Algorithm
{
    public List<KeyValuePair<string, int>> list;
    public int listLength;

    private string m_Lore = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";

    public override void PrepareData(object data)
    {
        list = new List<KeyValuePair<string, int>>();
        Dictionary<string, int> tempData = data as Dictionary<string, int>;
        foreach (KeyValuePair<string, int> item in tempData)
        {
            list.Add(item);
        }
        listLength = list.Count();
    }

    public override void RunAlgorithm()
    {
        Sort();
    }

    public override void PrintResults()
    {
        string result = ListToText(list);
        Debug.Log("Result = " + result);
    }

    private string ListToText(IEnumerable list)
    {
        string result = "";
        foreach (var listMember in list)
        {
            result += listMember.ToString() + " ";
        }
        return result;
    }

    private void Sort()
    {
        bool finished = true;
        int listLength = list.Count;
        for (int i = 0; i < listLength; i++)
        {
            if(i < listLength - 1)
            {
                KeyValuePair<string, int> listI = list[i];
                KeyValuePair<string, int> listNext = list[i + 1];
                if (Score(listI) > Score(listNext))
                {
                    list[i] = listNext;
                    list[i + 1] = listI;
                    finished = false;
                }
            }
            i++;
        }
        if (!finished)
        {
            Sort();
        }
    }

    private int Score(KeyValuePair<string, int> item)
    {
        int score = 0; // dictionary entry is sorted based on score
        string str = m_Lore.Substring(0, item.Value); // take first x elements from lore ipsum string, where x is age of person
        foreach (char letter in item.Key) // iterate over persons name
        {
            foreach (char c in str) // each occurence of each letter in ipsum substring is 1 point
            {
                if (c == letter) score++;
            }
        }
        return score;
    }
}
