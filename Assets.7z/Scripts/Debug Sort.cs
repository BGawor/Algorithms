﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugSort : Algorithm
{
    public override void PrepareData(object data) { }

    public override void RunAlgorithm()
    {
        string debugString = "";
        for (int i = 0; i < 99; i++)
        {
            debugString += "42";
        }
    }
    public override void PrintResults()
    {
    }
}
